/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan.pkg2;

/**
 *
 * @author riki
 */
public class Pertemuan2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Pertemuan2 per = new Pertemuan2();
        System.out.println("=====Variable=====");
        per.perVariabel();
        System.out.println("=====Perbandingan=====");
        per.perPercabanganIf();
        System.out.println("=====Nilai=====");
        per.perPercabanganIF();
        System.out.println("=====lampu=====");
        per.perPercabanganSwitch();
         }
    
    void perVariabel(){
//    deklarasi variabel
String nama_depan, namaBelakang, alamat;
int npm, umur,noHp;
// isi variable
nama_depan = "Dikky";
namaBelakang ="Rahmadana";
alamat ="Solsel";
npm =19100061;
umur= 21;
noHp=5928;
// cetak
        System.out.println("Nama : " + nama_depan + " " + namaBelakang)";
        System.out.println("Alamat : " + alamat);
        System.out.println("NPM : " + npm);
        System.out.println("No Hp : " + noHp);
        System.out.println("Umur : " + umur);
    }    
    
    void perPercabanganIf() {
        int belanja =15000000;
        
//  mengambil input
        System.out.println("Total Belanja Rp : " + belanja +" ");
        
//  pecabangan if dengan nimonal 150000
        if (belanja >= 150000000) {
            System.out.println("Selamat Anda Mendapatkan Hadiah");
        }
        
        System.out.println("Terima Kasih Telah Belanja di Toko Kami");
    }
    
    
    void perPercabanganIF(){
      int nilai;
        String grade;
//         Mengambil input
            System.out.println("Inputkan nilai: ");
            nilai = 81;
//            hitung gradenya
            if ( nilai > 90 && nilai <= 100) {
                grade = "A";
            }else if ( nilai > 80 && nilai <= 90){
                grade = "B+";
            }else if ( nilai > 70 && nilai <= 80){
                grade = "B"; 
            }else if ( nilai > 60 && nilai <= 70){
                grade = "C+";
            }else if ( nilai > 50 && nilai <= 60){
                grade = "C";  
            }else if ( nilai > 40 && nilai <= 50){
                grade = "D";
            }else {
                grade = "E";
            }
//            cetak hasilnya
            System.out.println("Grade: " + grade);
 
}
   
    void perPercabanganSwitch(){
        String lampu;
        
//        mengambil input
        System.out.println("inputkan nama warna:");
        lampu = "hijau";
        
        switch(lampu){
             case"merah":
                 System.out.println("lampu merah,berhenti!");
                 break;
             case"kuning":
                 System.out.println("lampu kuning,hati-hati!");
                 break;
             case"hijau":
                 System.out.println("lampu hijau,jalan!");
             default:
                 System.out.println("Warna lampu salah");
        }
    }