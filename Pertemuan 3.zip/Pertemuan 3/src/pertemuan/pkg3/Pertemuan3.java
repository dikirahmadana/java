/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan.pkg3;
import javax.swing.JOptionPane;

/**
 *
 * @author riki
 */
public class Pertemuan3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String kondisi;
        kondisi = JOptionPane.showInputDialog(null, "silahkan pilih kondisi : [Biodata, Kalkulator]");
        Pertemuan3 per = new Pertemuan3 ();
        if (kondisi.equals("Biodata")){
           per.Biodata();
        } else if (kondisi.equals("Kalkulator")){
            per.Kalkulator();       
        } 
    }
   
void Biodata(){
    String nama_depan,nama_belakang,tempat,tgl_lahir,alamat,matkul,grade;
    int nohp,nilai;
    
//     input dengan JOptionPane
    
    nama_depan =JOptionPane.showInputDialog(null, "masukan nama depan:");
    nama_belakang = JOptionPane.showInputDialog(null, "masukkan nama belakang:");
    tempat = JOptionPane.showInputDialog(null, "masukan tempat lahir anda:");
    tgl_lahir =JOptionPane.showInputDialog(null, "masukan tanggal lahir anda:");
    nohp =Integer.parseInt(JOptionPane.showInputDialog(null, "masukan nohp anda:"));
    matkul =JOptionPane.showInputDialog(null, "masukan nama mata kuliah anda hari ini:");
    nilai =Integer.parseInt(JOptionPane.showInputDialog(null, "masukan nilai mata kuliah anda:"));
    alamat =JOptionPane.showInputDialog(null, "masukan alamat anda:");
    
//    hitung gradenya
    if (nilai > 90 && nilai <=100){
        grade = "A";
    }else if (nilai > 80 && nilai <=90){
        grade = "B+";
    }else if (nilai > 70 && nilai <=80){
        grade = "B";
    }else if (nilai > 60 && nilai <=70){
        grade = "C+";
    }else if (nilai > 50 && nilai <=60){
        grade = "C";
    }else if (nilai > 40 && nilai <=50){
        grade = "D";
    }else{
        grade = "E";
    }
//   cetak hasilnya
    System.out.println("grade:" + grade);
//    output popup
    JOptionPane.showInputDialog(null, "=====Biodata=====\n"
        +"nama : "+ nama_depan + "  " + nama_belakang + "\n"
        +"tempat/tempat lahir : " + tempat +" /" + tgl_lahir + "\n"
        +"nohp : " + nohp + "\n"
        +"nama mata kuliah saat ini : " + matkul + "\n"
        +"alamat : " + alamat + "\n"
        +"nilai angka : " + nilai + "\n"
        +"nilai huruf : " + grade 
    );
}

void Kalkulator(){
    System.out.println("ini Kalkulator");
    String bilangan1,bilangan2;
    int nilai1,nilai2
           
//      input kalkulator menggunakan JOption
            bilangan1 = JOptionPane.showInputDialog(null, "masukan bilangan1=");
            bilangan2 = JOptionPane.showInputDialog(null, "masukan bilangan2=");
            
            nilai1 = Integer.parseInt(bilangan1)
            nilai2 = Integer.parseInt(bilangan2)
                    
            int tambah = nilai1 + nilai2;
            int kurang = nilai1 - nilai2;
            int kali = nilai1 * nilai2;
            int bagi = nilai1 / nilai2;
            
            
//      output popup
            
            JOptionPane.showMessageDialog(null, " hasil dari " + nilai1 + " + " + nilai2 + " adalah " + tambah);
            JOptionPane.showMessageDialog(null, " hasil dari " + nilai1 + " - " + nilai2 + " adalah " + kurang);
            JOptionPane.showMessageDialog(null, " hasil dari " + nilai1 + " * " + nilai2 + " adalah " + kali);
            JOptionPane.showMessageDialog(null, " hasil dari " + nilai1 + " / " + nilai2 + " adalah " + bagi);
}
}